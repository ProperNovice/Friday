package utils;

public interface IListSize {

	public int getSize();

}
