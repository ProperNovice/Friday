package utils;

public enum RearrangeTypeEnum {
	LINEAR, PIVOT, STATIC
}
