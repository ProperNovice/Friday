package utils;

public enum DirectionEnum {
	LEFT, RIGHT, UP, DOWN
}
