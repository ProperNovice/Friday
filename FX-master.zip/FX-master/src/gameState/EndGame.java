package gameState;

public class EndGame extends AGameState {

	@Override
	public void handleGameStateChange() {
		
	}

}
