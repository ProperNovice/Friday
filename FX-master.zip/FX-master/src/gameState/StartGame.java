package gameState;

public class StartGame extends AGameState {

	@Override
	public void handleGameStateChange() {

	}

}
