package controller;

public enum Modifiers {

	INSTANCE;

}
