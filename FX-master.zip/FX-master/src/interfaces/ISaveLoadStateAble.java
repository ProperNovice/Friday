package interfaces;

public interface ISaveLoadStateAble {

	public void saveGameStart();

	public void loadGameStart();

	public void saveState();

	public void loadState();

}
